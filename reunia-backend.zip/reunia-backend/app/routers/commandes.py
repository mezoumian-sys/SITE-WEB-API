from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
from app.schemas.commandes import (
    CommandeCreate, CommandeUpdate, CommandeOut,
    PaginatedCommandes, StatutCommande,
)
from app.services import commandes_service as svc
from app.core.security import require_admin

router = APIRouter()


# ══════════════════════════════════════════
#  PUBLIC — Passer une commande / Suivre
# ══════════════════════════════════════════

@router.post("/commandes", response_model=CommandeOut, tags=["Commandes"])
async def passer_commande(data: CommandeCreate):
    """
    Endpoint public — un client passe une commande.
    Vérifie le stock, calcule le total, génère le numéro RN-XXXX.
    """
    try:
        return await svc.create_commande(data)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Erreur lors de la commande : {str(e)}")


@router.get("/commandes/suivi/{numero}", response_model=CommandeOut, tags=["Commandes"])
async def suivre_commande(numero: str):
    """
    Permet à un client de suivre sa commande par son numéro (ex: RN-2025-0042).
    Endpoint public — pas besoin de compte.
    """
    commande = await svc.get_commande_by_numero(numero.upper())
    if not commande:
        raise HTTPException(404, "Commande introuvable. Vérifiez le numéro.")
    return commande


# ══════════════════════════════════════════
#  ADMIN — Gestion des commandes
# ══════════════════════════════════════════

@router.get("/commandes", response_model=PaginatedCommandes, tags=["Commandes"])
async def list_commandes(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    statut: Optional[StatutCommande] = None,
    search: Optional[str] = None,
    _=Depends(require_admin),
):
    """Admin — liste toutes les commandes avec filtres."""
    return await svc.list_commandes(page, per_page, statut, search)


@router.get("/commandes/stats", tags=["Commandes"])
async def dashboard_stats(_=Depends(require_admin)):
    """Admin — statistiques pour le dashboard."""
    return await svc.get_stats()


@router.get("/commandes/{commande_id}", response_model=CommandeOut, tags=["Commandes"])
async def get_commande(commande_id: str, _=Depends(require_admin)):
    commande = await svc.get_commande(commande_id)
    if not commande:
        raise HTTPException(404, "Commande introuvable")
    return commande


@router.patch("/commandes/{commande_id}", response_model=CommandeOut, tags=["Commandes"])
async def update_commande(
    commande_id: str,
    data: CommandeUpdate,
    _=Depends(require_admin),
):
    """Admin — met à jour le statut, ajoute un numéro de suivi ou une note."""
    return await svc.update_commande_statut(commande_id, data)
