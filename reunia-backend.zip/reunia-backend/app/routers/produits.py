from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Query
from typing import Optional
from app.schemas.produits import (
    ProduitCreate, ProduitUpdate, ProduitOut, PaginatedProduits,
    CategorieCreate, CategorieUpdate, CategorieOut,
)
from app.services import produits_service as svc
from app.core.security import require_admin

router = APIRouter()


# ══════════════════════════════════════════
#  CATÉGORIES — publiques en lecture
# ══════════════════════════════════════════

@router.get("/categories", response_model=list[CategorieOut], tags=["Catégories"])
async def get_categories(active_only: bool = True):
    """Liste toutes les catégories (avec nombre de produits)."""
    return await svc.list_categories(active_only)


@router.get("/categories/{categorie_id}", response_model=CategorieOut, tags=["Catégories"])
async def get_categorie(categorie_id: str):
    cat = await svc.get_categorie(categorie_id)
    if not cat:
        raise HTTPException(404, "Catégorie introuvable")
    return cat


@router.post("/categories", response_model=CategorieOut, tags=["Catégories"])
async def create_categorie(data: CategorieCreate, _=Depends(require_admin)):
    """Admin seulement."""
    return await svc.create_categorie(data)


@router.patch("/categories/{categorie_id}", response_model=CategorieOut, tags=["Catégories"])
async def update_categorie(categorie_id: str, data: CategorieUpdate, _=Depends(require_admin)):
    return await svc.update_categorie(categorie_id, data)


@router.delete("/categories/{categorie_id}", tags=["Catégories"])
async def delete_categorie(categorie_id: str, _=Depends(require_admin)):
    await svc.delete_categorie(categorie_id)
    return {"message": "Catégorie supprimée"}


# ══════════════════════════════════════════
#  PRODUITS — publics en lecture
# ══════════════════════════════════════════

@router.get("/produits", response_model=PaginatedProduits, tags=["Produits"])
async def get_produits(
    page: int = Query(1, ge=1),
    per_page: int = Query(12, ge=1, le=50),
    categorie_id: Optional[str] = None,
    tissu: Optional[str] = None,
    search: Optional[str] = None,
    actif_only: bool = True,
):
    """Liste paginée des produits avec filtres."""
    return await svc.list_produits(page, per_page, categorie_id, tissu, search, actif_only)


@router.get("/produits/slug/{slug}", response_model=ProduitOut, tags=["Produits"])
async def get_produit_by_slug(slug: str):
    produit = await svc.get_produit_by_slug(slug)
    if not produit:
        raise HTTPException(404, "Produit introuvable")
    return produit


@router.get("/produits/{produit_id}", response_model=ProduitOut, tags=["Produits"])
async def get_produit(produit_id: str):
    produit = await svc.get_produit(produit_id)
    if not produit:
        raise HTTPException(404, "Produit introuvable")
    return produit


@router.post("/produits", response_model=ProduitOut, tags=["Produits"])
async def create_produit(data: ProduitCreate, _=Depends(require_admin)):
    return await svc.create_produit(data)


@router.patch("/produits/{produit_id}", response_model=ProduitOut, tags=["Produits"])
async def update_produit(produit_id: str, data: ProduitUpdate, _=Depends(require_admin)):
    return await svc.update_produit(produit_id, data)


@router.delete("/produits/{produit_id}", tags=["Produits"])
async def delete_produit(produit_id: str, _=Depends(require_admin)):
    await svc.delete_produit(produit_id)
    return {"message": "Produit archivé"}


# ══════════════════════════════════════════
#  UPLOAD IMAGE
# ══════════════════════════════════════════

@router.post("/produits/upload-image", tags=["Produits"])
async def upload_image(
    file: UploadFile = File(...),
    _=Depends(require_admin),
):
    """Upload une image produit → Supabase Storage. Retourne l'URL publique."""
    if file.content_type not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(400, "Format accepté : JPEG, PNG, WEBP")
    if file.size and file.size > 5 * 1024 * 1024:
        raise HTTPException(400, "Taille max : 5MB")

    data = await file.read()
    url = await svc.upload_image(data, file.filename)
    return {"url": url}
